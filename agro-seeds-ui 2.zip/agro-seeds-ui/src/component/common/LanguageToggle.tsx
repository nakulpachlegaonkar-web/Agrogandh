import { useTranslation } from "react-i18next";
import "./languageToggle.css";

export default function LanguageToggle() {
  const { i18n } = useTranslation();
  const isMarathi = i18n.language === "mr";

  const toggleLanguage = () => {
    i18n.changeLanguage(isMarathi ? "en" : "mr");
  };

  return (
    <div className="lang-switch">
      <span className={!isMarathi ? "active" : ""}>EN</span>

      <label className="switch">
        <input
          type="checkbox"
          checked={isMarathi}
          onChange={toggleLanguage}
        />
        <span className="slider" />
      </label>

      <span className={isMarathi ? "active" : ""}>मराठी</span>
    </div>
  );
}