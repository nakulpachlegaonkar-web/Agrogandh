import { motion } from "framer-motion";
import "./newsEvents.css";

const news = [
  {
    title: "New Onion Seed Variety Launched",
    date: "12 Aug 2026",
    description:
      "Agrogandh Seeds launches a high-yield onion seed suitable for all climates.",
  },
  {
    title: "Farmer Training Camp – Nashik",
    date: "25 Aug 2026",
    description:
      "Join our experts for live demonstrations on best farming practices.",
  },
  {
    title: "Agrogandh at Krushi Expo 2026",
    date: "05 Sep 2026",
    description:
      "Visit our stall at Krushi Expo to explore our premium seed portfolio.",
  },
];

export default function NewsEvents() {
  return (
    <section className="news">
      <h2 className="news-title">📰 News & Events</h2>

      <div className="news-grid">
        {news.map((item, i) => (
          <motion.div
            key={i}
            className="news-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.15 }}
            whileHover={{ scale: 1.04 }}
          >
            <span className="news-date">{item.date}</span>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}