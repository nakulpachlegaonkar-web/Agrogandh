import { motion } from "framer-motion";

export default function Footer() {
  return (
    <header className="footer">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <p>© 2026 Agrogandh Agro Pvt Ltd</p>
        <p>Growing Trust. Growing Future 🌾</p>
      </motion.div>
    </header>
  );
}
