import { motion } from "framer-motion";
import LanguageToggle from "../common/LanguageToggle";
import "./header.css";
import { useAppText } from "../../hooks/useAppText";

export default function Header() {
  const text = useAppText();

  return (
    <header className="header compact">
      <motion.div
        className="header-inner"
        initial={{ opacity: 0, y: -15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {/* Brand */}
        <div className="brand">
          <h1>🌱 {text.brand}</h1>
          <span>{text.tagline}</span>
        </div>

        {/* Right side: Contact + Language */}
        <div className="header-right">
          <div className="contact">
            <a href="tel:+919876543210">📞 +91 98765 43210</a>
            <a href="mailto:info@agrogandh.com">✉️ info@agrogandh.com</a>
          </div>

          <LanguageToggle />
        </div>
      </motion.div>
    </header>
  );
}