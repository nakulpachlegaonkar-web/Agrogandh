import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import "./heroSlider.css"

const images = [
  // 🌱 Chia Seeds
  "src/public/images/seeds/WhatsApp Image 2026-02-08 at 01.24.58.jpeg",

  // 🧅 Onion Close-up
  "src/public/images/seeds/WhatsApp Image 2026-02-08 at 01.27.55.jpeg",

  // 🚜 Onion Farm / Field
  "https://images.unsplash.com/photo-1508747703725-719777637510",
];

export default function HeroSlider() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % images.length);
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="hero">
      <AnimatePresence mode="wait">
        <motion.img
          key={index}
          src={images[index]}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5 }}
          alt="Agrogandh Seeds Banner"
        />
      </AnimatePresence>
    </section>
  );
}