import { motion } from "framer-motion";
import "./seedComparison.css";

const data = [
  {
    name: "Chia Seeds",
    yield: "High",
    duration: "90 Days",
    climate: "Dry",
  },
  {
    name: "Onion Seeds",
    yield: "Medium",
    duration: "120 Days",
    climate: "Moderate",
  },
];

export default function SeedComparison() {
  return (
    <section className="comparison">
      <h2 className="comparison-title">📊 Seed Comparison</h2>

      <div className="comparison-grid">
        {data.map((seed, i) => (
          <motion.div
            key={i}
            className="comparison-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.15 }}
            whileHover={{ scale: 1.05 }}
          >
            <h3>{seed.name}</h3>

            <ul>
              <li>
                <span>🌾 Yield</span>
                <strong>{seed.yield}</strong>
              </li>
              <li>
                <span>⏱ Duration</span>
                <strong>{seed.duration}</strong>
              </li>
              <li>
                <span>🌦 Climate</span>
                <strong>{seed.climate}</strong>
              </li>
            </ul>
          </motion.div>
        ))}
      </div>
    </section>
  );
}