import "./whatsappChat.css";

export default function WhatsAppChat() {
  const phoneNumber = "919876543210"; // country code + number
  const message = "Hello, I would like to know more about your seeds.";

  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(
    message
  )}`;

  return (
    <a
      href={whatsappUrl}
      className="whatsapp-chat"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
    >
      💬
    </a>
  );
}