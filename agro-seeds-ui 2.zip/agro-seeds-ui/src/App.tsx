
import Header from "./component/layout/header";
import Footer from "./component/layout/footer";
import AdminAds from "./component/admin/SmartActions";
import CropSuggestion from "./component/ai/CropSuggestion";
import DealerEnquiry from "./component/enquiry/DealerEnquiry";
import HeroSlider from "./component/hero/HeroSlider";
import SeedComparison from "./component/seeds/SeedComparison";
import Testimonials from "./component/testimonials/Testimonials";
import SeedGrowthVideo from "./component/media/SeedGrowthVideo";
import SmartActions from "./component/admin/SmartActions";
import NewsEvents from "./component/news/NewsEvents";
import WhatsAppChat from "./component/chat/WhatsAppChat";

export default function App() {
  return (
    <div>
      <Header />
      <HeroSlider />
      <Testimonials />
      <SeedComparison />
      <SmartActions />
      <SeedGrowthVideo />
      <NewsEvents></NewsEvents>
       <WhatsAppChat />
      <Footer />
    </div>
  );
}
